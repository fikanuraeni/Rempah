package com.example.sejutamanfaatrempahindonesia.data

data class User(
    var id: Int = 0,
    var name: String = "",
    var description: String = "",
    var detail: String = "",
    var img: Int = 0,
)
